 <?php
 session_start();
include_once '../modelo/Usuario.php';
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of ControlUsuario
 *
 * @author Dell
 */
class ControlUsuario {
   public static function recuperar_accion(){
        
        $accion = $_REQUEST["accion"];
        switch ($accion) {
            case "Guardar":
                ControlUsuario::guardar_usuario();

                break;
            
            case "Buscar":
                ControlUsuario::buscar_usuario();

                break;

            default:
                break;
        }
    }
    public static function buscar_usuario() {
        $cedula = $_REQUEST["cedula"];
        $usuario = Usuario::find_by_cedula($cedula); 
        
        if($usuario !=NULL){
             $usuario= serialize($usuario);
             $_SESSION["usuario.encontrado"] = $usuario;
              header("Location: ../Usuario/buscar.php?mensaje=ok, usuario encontrado");
         }
         else{
             header("Location: ../Usuario/buscar.php?mensaje= usuario $cedula no existe");
         }
    }

    public static function guardar_usuario() {
        $cedula = $_REQUEST["cedula"];
        $clave = $_REQUEST["clave"];
        $nombre = $_REQUEST["nombre"];
        $apellido = $_REQUEST["apellido"];
        $genero = $_REQUEST["genero"];
        $email = $_REQUEST["email"];
//        echo "$cedula ,
//           $clave, $nombre, $apellido,$genero,
//                        $email";
                
                $usuario = new Usuario(); 
                 $usuario ->cedula = $cedula;
                $usuario ->password = $clave;
                $usuario ->nombre = $nombre;
             $usuario ->apellido = $apellido;
             $usuario ->genero = $genero;
             $usuario ->email = $email;
             try {
                 $res = $usuario->save();
                 header("Location: ../Usuario/agregar.php?mensaje=ok, propietario guardado");
               
             } catch (Exception $exc) {
                header("Location: ../Usuario/agregar.php?mensaje=Error: Usuario ya fue registrado previamente");
                 
             }

             
             
             
    }
}
ControlUsuario::recuperar_accion();
