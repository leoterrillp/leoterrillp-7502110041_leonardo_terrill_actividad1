<?php
require_once $_SERVER['DOCUMENT_ROOT'].'carrerataxi/lib/activerecord/ActiveRecord.php';
ActiveRecord\Config::initialize(function($cfg)
{
   $cfg->set_model_directory($_SERVER['DOCUMENT_ROOT'].'carrerataxi/modelo/entidades');
   $cfg->set_connections(
     array(
       'development' => 'mysql://root:root@localhost/carrerataxi_web_2023_1'
       //,
       //'test' => 'mysql://root:root@localhost/carrerataxi_web_2023_1',
       //'production' => 'mysql://root:root@localhost/carrerataxi_web_2023_1',
     )
   );
});