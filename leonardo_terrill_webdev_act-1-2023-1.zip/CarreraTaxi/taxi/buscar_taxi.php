<?php
session_start();
include_once '../modelo/CarreraTaxi.php';
$carreraTaxi = @$_SESSION["carrerataxi.encontrado"];
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>::EJEMPLO SIMPLE CON PHP Y MySQL ::</title>
</head>
<body>
<center>
<h2>FORMULARIO PARA BUSCAR TAXI<h2>
<hr/>
<form action ="../controladores/ControlTaxi.php" method="POST">
<fieldset style="width: 20%; text-align:left">
<legend style="color:blue">Ingrese los datos de acceso: </legend>
<table border="0">
    
    
<tr>  
<th>PLACA:</th>
<td>
<input name="id" type="number" required/>
</td>
</tr>

<tr>
<th>CLIENTE:</th>
<td>
    <input name="cliente" type="text" readonly value="<?= @$CarreraTaxi->cliente?>"/>
</td>


</tr>
<tr>
<th>TAXI:</th>
<td>
<input name="taxi" type="text" readonly value="<?= @$CarreraTaxi->taxi?>"/>
</td>
</tr>

</tr>
<tr>
<th>KILOMETROS:</th>
<td>
<input name="kilometros" type="number" readonly  value="<?= @$CarreraTaxi->kilometros?>"/>
</td>
</tr>


</tr>
<tr>
<th>BARRIO INICIO:</th>
<td>
<input name="barrio_inicio" type="text" readonly value="<?= @$CarreraTaxi->barrio_inicio?>"/>
</td>
</tr>



</tr>
<tr>
<th>BARRIO LLEGADA:</th>
<td>
<input name="barrio_llegada" type="text" readonly value="<?= @$CarreraTaxi->barrio_llegada?>"/>
</td>
</tr>

</tr>
<tr>
<th>CANTIDAD PASAJEROS:</th>
<td>
<input name="cantidad_pasajeros" type="text" readonly value="<?= @$CarreraTaxi->cantidad_pasajeros?>"/>
</td>
</tr>


</tr>
<tr>
<th>TAXISTA:</th>
<td>
<input name="taxista" type="text" readonly value="<?= @$CarreraTaxi->taxista?>"/>
</td>
</tr>




</tr>
<tr>
<th>PRECIO:</th>
<td>
<input name="precio" type="number" readonly value="<?= @$CarreraTaxi->precio?>"/>
</td>
</tr>

</tr>
<tr>
<th>DURACION MINUTOS:</th>
<td>
<input name="duracion_minutos" type="number" readonly value="<?= @$CarreraTaxi->duracion_minutos?>"/>
</td>
</tr>

<tr>
<td colspan="2" style="text-aling:center">
<input name="accion" type="submit" value="Guardar"/>&nbsp;&nbsp;&nbsp;
<input type="reset" value="Limpiar"/>
</td>

</tr>
</table>
</fieldset>
</form>
<span style="color: red"><?=@($_REQUEST["mensaje"])?$_REQUEST["mensaje"]:""?></span>

</center>
</body>
</html>
