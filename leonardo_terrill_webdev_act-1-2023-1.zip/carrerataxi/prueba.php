<?php
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/entidades/Usuario.php';
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/entidades/Taxi.php';
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/crud/CrudUsuario.php';
// $u = new Usuario();  
// $u->cedula="256";
// $u->pass="abc";
// $u->nombre="fulanito";
// $u->apellido="detal";
// $u->genero="masculino";
// $u->email="leotres@gamil.com";
// try 
//     $u->save();
//     $total= @Usuario::count();
//     print("TOTAL: " .$total );
// } catch (Exception $error) {
//     $msj= $error->getMessage();
//     if(strstr($msj, "Duplicate entry")){
//         echo "El usuario con cedula $u->cedula ya existe";
//     }
//     else{
//         echo "El usuario no fue insertado en la base de datos, error desconocido";
//     }

// } 

// $u = Usuario::find('123');
// if($u != NULL){
// echo $u->nombre;
// }
// else{
//     echo "Usuario con Cedula:123 No existe";
// }

try {
    // $u = CrudUsuario::buscar("123");
    // $u->nombre = "fulanito4";
    // $u->pass ="abcd";
    // CrudUsuario::editar($u);
    $total = CrudUsuario::contar();
    echo"TOTAL: $total<br>";
    $user = new Usuario();
    $user->cedula = "123";
    CrudUsuario::eliminar($user);
    echo"Usuario eliminado";
    $total = CrudUsuario::contar();
    echo"TOTAL: $total<br>";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage;
}