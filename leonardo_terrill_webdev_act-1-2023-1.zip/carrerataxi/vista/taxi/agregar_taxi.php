<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USUARIOS DEL TAXI</title>
    <style type="text/css"> 
    .etiqueta {
        text-aling:right;
        color:blue;
    }
        </style>
</head>
<body>
            <center>
                <h2>AGREGAR USUARIO</h2>
                <HR style="width: 40%;">
                <form action="../../controladores/ControladorTaxis.php">
                    <fieldset style="width: 40%;">
                        <legend>DATOS DEL TAXI:</legend>
                            <table border="1">
                                <tr>
                                    <th class="etiqueta">ID:</th>
                                    <td><input type="number" required name="id" placeholder="INGRESE LA CEDULA"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta">CLIENTE:</th>
                                    <td><input type="text" required name="cliente" placeholder="INGRESE LA CONTRASEÑA"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >TAXI:</th>
                                    <td><input type="text" required name="taxi" placeholder="INGRESE EL NOMBRE"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >KILOMETROS:</th>
                                    <td><input type="number" required name="kilometros" placeholder="INGRESE LOS KILOMETROS"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >BARRIO INICIO:</th>
                                    <td><input type="text" required name="barrio_inicio" placeholder="INGRESE BARRIO INICIO"></td>
                                </tr>


                                <tr>
                                    <th class="etiqueta" >BARRIO LLEGADA:</th>
                                    <td><input type="text" required name="barrio_llegada" placeholder="INGRESE BARRIO LLEGADA"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >CANTIDAD DE PASAJEROS:</th>
                                    <td><input type="number" required name="cantidad_pasajeros" placeholder="INGRESE CANTIDAD DE PASAJEROS"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >TAXISTA:</th>
                                    <td><input type="text" required name="taxista" placeholder="INGRESE TAXISTA"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >PRECIO:</th>
                                    <td><input type="number" required name="precio" placeholder="INGRESE PRECIO"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >DURACION MINUTOS:</th>
                                    <td><input type="text" required name="duracion_minutos" placeholder="DURACION MINUTOS"></td>
                                </tr>

                                <tr>
                                    
                                    <td style="text-aling: center; " colspan="2">
                                        <input type="reset" value="LIMPIAR">

                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="submit" name="accion" value="GUARDAR"></td>
                                    </td>
                                </tr> 
                            </table>
                    </fieldset>   
                    </form> 
            </center>
</body>
</html>