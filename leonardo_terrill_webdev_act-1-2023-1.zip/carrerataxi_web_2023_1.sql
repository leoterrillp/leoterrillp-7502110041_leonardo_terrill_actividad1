-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 24-04-2023 a las 17:23:47
-- Versión del servidor: 5.7.11
-- Versión de PHP: 7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `carrerataxi_web_2023_1`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `taxis`
--

CREATE TABLE `taxis` (
  `id` int(11) NOT NULL,
  `cliente` varchar(100) NOT NULL,
  `taxi` varchar(100) NOT NULL,
  `kilometros` varchar(100) NOT NULL,
  `barrioInicio` varchar(100) NOT NULL,
  `barrioLLegada` varchar(100) NOT NULL,
  `cantidadPasajeros` varchar(100) NOT NULL,
  `taxista` varchar(100) NOT NULL,
  `precio` varchar(100) NOT NULL,
  `duracionMinutos` varchar(100) NOT NULL,
  `usuario_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `cedula` int(11) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`cedula`, `pass`, `nombre`, `apellido`, `genero`, `email`) VALUES
(234, 'abc', 'fulanito', 'detal', 'masculino', 'leodos@gamil.com'),
(256, 'abc', 'fulanito', 'detal', 'masculino', 'leotres@gamil.com'),
(1234567, '12345', 'Lo que sea', 'lo que sea', 'hombre', 'alsas@daskda.com');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `taxis`
--
ALTER TABLE `taxis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_taxi_usuarios` (`usuario_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`cedula`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `taxis`
--
ALTER TABLE `taxis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `taxis`
--
ALTER TABLE `taxis`
  ADD CONSTRAINT `fk_taxi_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`cedula`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
