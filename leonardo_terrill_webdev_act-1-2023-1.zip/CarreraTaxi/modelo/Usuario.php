<?php
include_once '../libs/configuracion.php';
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Usuario
 *
 * @author Dell
 */
class Usuario extends ActiveRecord\Model{
     static $table_name ="Usuario";
     static $primary_key = 'cedula';
}
