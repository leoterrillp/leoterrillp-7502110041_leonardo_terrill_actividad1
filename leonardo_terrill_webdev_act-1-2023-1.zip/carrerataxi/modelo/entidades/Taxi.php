<?php
require_once $_SERVER["DOCUMENT_ROOT"].'/carrerataxi/lib/config.php';

class Taxi extends ActiveRecord\Model{

    
    public static $belongs_to = array(array("usuario"));
}