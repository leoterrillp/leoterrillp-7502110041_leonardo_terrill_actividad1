<?php
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/entidades/Usuario.php';
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/entidades/Taxi.php';
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/crud/CrudTaxi.php';


class ControladorTaxis{

    public static function accion(){

        $accion = $_REQUEST["accion"];

        switch($accion){
            case "GUARDAR":
                ControladorUsuarios::guardar_taxi();

    }
        
    }


    public static function guardar_taxi(){

        
    }

}