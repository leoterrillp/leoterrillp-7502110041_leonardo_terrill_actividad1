<?php
include_once '../libs/configuracion.php';
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of CarreraTaxi
 *
 * @author Dell
 */
class CarreraTaxi extends ActiveRecord\Model{
    static $table_name ="CarreraTaxi";
     static $primary_key = 'id';
}
