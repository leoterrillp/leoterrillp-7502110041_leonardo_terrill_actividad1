<?php
class CrudUsuario {

    public static function guardar($u){
        try {
    $u->save();
        } catch (Exception $error) {
    throw new Exception ("Error al guardar el usuario <br>".$error->getMessage());
        }

}




public static function buscar_usuarios($cc){
try {
    return Usuario::find($cc);
} catch (Exception $error) {
    throw new Exception("Error al buscar el usuario<br>Detalles: ". $error->getMessage());
}

}


public static function editar($u){
try {
    $u->save();
} catch (Exception $error) {
    throw new Exception("Error al editar el usuario -> Detalles: " . $error->getMessage());
    
}

}
 

public static function eliminar($u){
    try {
        $u->delete();
    } catch (Exception $error) {
        throw new Exception("Error al editar el usuario -> Detalles: " . $error->getMessage());
        
    }
    
    }



    public static function contar($u){
        try {
           return Usuario::count();//SELECT count(*)from usuarios;
        } catch (Exception $error) {
            throw new Exception("Error al contar usuario -> Detalles: " . $error->getMessage());
            
        }
        
        }




        public static function obtener_todos_los_usuarios($u){
            try {
               return Usuario::all();//select * from usuarios
            } catch (Exception $error) {
                throw new Exception("Error al obtener todos los usuarios <br>Detalles: " . $error->getMessage());
                
            }
            
            }




            public static function buscar_usuarios_por_nombre($nombre){
                try {
                   return Usuario::find_by_nombre($nombre);//SELECT * from usuarios WHERE nombre =$nombre
                } catch (Exception $error) {
                    throw new Exception("Error al obtener todos los usuarios <br>Detalles: " . $error->getMessage());
                    
                }
                
                }
    


}