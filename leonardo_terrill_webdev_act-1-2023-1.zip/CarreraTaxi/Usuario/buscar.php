<?php
session_start();
include_once '../modelo/Usuario.php';
$usuario = @$_SESSION["usuario.encontrado"];
$usuario = @unserialize($usuario);
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>::EJEMPLO SIMPLE CON PHP Y MySQL ::</title>
</head>
<body>
<center>
<h2>FORMULARIO PARA BUSCAR USUARIO<h2>
<hr/>
<form action ="../controladores/ControlUsuario.php" method="POST">
<fieldset style="width: 20%; text-align:left">
<legend style="color:blue">Ingrese los datos de acceso: </legend>
<table border="0">
    
    
<tr>  
<th>CEDULA:</th>
<td>
<input name="cedula" type="number" required/>
</td>
</tr>

<tr>
<th>PASSWORD:</th>
<td>
<input name="clave" type="password" readonly value="<?=@$Usuario->password?>"/>
</td>


</tr>
<tr>
<th>NOMBRE:</th>
<td>
<input name="nombre" type="text" readonly value="<?=@$Usuario->nombre?>"/>
</td>
</tr>

</tr>
<tr>
<th>APELLIDO:</th>
<td>
<input name="apellido" type="text" readonly value="<?=@$Usuario->apellido?>"/>
</td>
</tr>


</tr>
<tr>
<th>GENERO:</th>
<td>
<input name="genero" type="text" readonly value="<?=@$Usuario->genero?>"/>
</td>
</tr>



</tr>
<tr>
<th>EMAIL:</th>
<td>
<input name="email" type="text" readonly value="<?=@$Usuario->email?>"/>
</td>
</tr>

<tr>
<td colspan="2" style="text-aling:center">
<input name="accion" type="submit" value="Guardar"/>&nbsp;&nbsp;&nbsp;
<input type="reset" value="Limpiar"/>
</td>

</tr>
</table>
</fieldset>
</form>
<span style="color: red"><?=@($_REQUEST["mensaje"])?$_REQUEST["mensaje"]:""?></span>

</center>
</body>
</html>
