<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USUARIOS DEL TAXI</title>
    <style type="text/css"> 
    .etiqueta {
        text-aling:right;
        color:blue;
    }
        </style>
</head>
<body>
            <center>
                <h2>AGREGAR USUARIO</h2>
                <HR style="width: 40%;">
                <form action="../../controladores/ControladorUsuarios.php" method="POST">
                    <fieldset style="width: 40%;">
                        <legend>DATOS DEL USUARIO:</legend>
                            <table border="1">
                                <tr> 
                                    <th class="etiqueta">CEDULA:</th>
                                    <td><input type="number" required name="cedula" placeholder="INGRESE LA CEDULA"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta">PASSWORD:</th>
                                    <td><input type="password" required name="clave" placeholder="INGRESE LA CONTRASEÑA"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >NOMBRE:</th>
                                    <td><input type="text" required name="nombre" placeholder="INGRESE EL NOMBRE"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >APELLIDO:</th>
                                    <td><input type="text" required name="apellido" placeholder="INGRESE EL APELLIDO"></td>
                                </tr>

                                <tr>
                                    <th class="etiqueta" >GENERO:</th>
                                    <td><input type="text" required name="genero" placeholder="INGRESE EL GENERO"></td>
                                </tr>


                                <tr>
                                    <th class="etiqueta" >EMAIL:</th>
                                    <td><input type="email" required name="correo" placeholder="INGRESE EL EMAIL"></td>
                                </tr>

                                <tr>
                                    
                                    <td style="text-aling: center; " colspan="2">
                                        <input type="reset" value="LIMPIAR">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="submit" name="accion" value="GUARDAR"></td>
                                    </td>
                                </tr> 
                            </table>
                    </fieldset> 
                    </form>  
            </center>
</body>
</html>