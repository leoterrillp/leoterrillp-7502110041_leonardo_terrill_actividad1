<?php
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/entidades/Usuario.php';
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/entidades/Taxi.php';
require_once $_SERVER['DOCUMENT_ROOT'] . 'carrerataxi/modelo/crud/CrudUsuario.php';
session_start();


class ControladorUsuarios{  

    public static function accion(){

        $accion = $_REQUEST["accion"];
        switch($accion){
                case "GUARDAR":
                    ControladorUsuarios::guardar_usuarios();
                    break;
                case "BUSCAR":
                    ControladorUsuarios::buscar_usuarios();
                    break;

                case "EDITAR":
                        ControladorUsuarios::editar_usuarios();
                        break;   
        }
    }

    public static function guardar_usuarios(){
        $cedula = $_REQUEST["cedula"];
        $clave = $_REQUEST["clave"];
        $nombre = $_REQUEST["nombre"];
        $apellido = $_REQUEST["apellido"];
        $genero = $_REQUEST["genero"];
        $email = $_REQUEST["correo"];

        $u = new Usuario();
        $u->cedula = $cedula;
        $u->nombre = $nombre;
        $u->apellido = $apellido;
        $u->genero = $genero;
        $u->email = $email;
        $u->pass = $clave;

        try {
            CrudUsuario::guardar($u);
            $total = CrudUsuario::contar();
            $msj = "Usuario guardado, Total:" .$total;
            header("Location: ../vista/usuarios/agregar.php?msj=$msj");
            exit; 
        } catch (Exception $error) {
            echo $error;
            header("Location: ../vista/usuarios/agregar.php");
            exit; 
        }
    }


public function buscar_usuarios(){
    $cedula = $_REQUEST["cedula"];
    $pagina = $_REQUEST["pagina"];
    try {
        $usuario = CrudUsuario::buscar_usuarios($cedula);
        $usuario = serialize($usuario);
        $_SESSION["usuario"] = $usuario;
        header("Location: ../vista/usuarios/buscar.php?msj=Usuario encontrado");
    }
     catch (Exception $error) {
        unset($_SESSION["usuario"]);
        echo $error;
        header("Location: ../vista/usuarios/buscar.php");
    }

}
public function editar_usuarios(){
    $cedula = $_REQUEST["cedula"];
    $clave = $_REQUEST["clave"];
    $nombre = $_REQUEST["nombre"];
    $apellido = $_REQUEST["apellido"];
    $genero = $_REQUEST["genero"];
    $email = $_REQUEST["correo"];


    $usuario = @$_SESSION["usuario"];
    $usuario = @unserialize($usuario);

    $clave->clave = $clave;
    $nombre->nombre = $nombre;
    $apellido->apellido = $apellido;
    $genero->genero = $genero;
    $email->email = $email;
    $resultado = CrudUsuario::editar_usuarios($usuario);
    if(resultado !=false){
        unset($_SESSION["usuario"]);
        header("Location: ../vista/usuarios/editar.php?msj=Usuario encontrado");
    }
    else{
        unset($_SESSION["usuario"]);
        header("Location: ../vista/usuarios/editar.php?msj=Usuario no puede ser editado");
    }

}

}
ControladorUsuarios::accion();