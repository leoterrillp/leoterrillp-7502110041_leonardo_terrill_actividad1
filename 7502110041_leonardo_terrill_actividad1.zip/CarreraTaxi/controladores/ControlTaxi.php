<?php
session_start();
include_once '../modelo/CarreraTaxi.php';
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of ControlTaxi
 *
 * @author Dell
 */
class ControlTaxi {
    public static function recuperar_accion(){
        
        $accion = $_REQUEST["accion"];
        switch ($accion) {
            case "Guardar":
                ControlTaxi::guardar_taxi();

                
                case "Buscar":
                ControlTaxi::buscar_taxi();
                break;

            default:
                break;
        }
    }
    
     public static function buscar_taxi() {
         $id = $_REQUEST["id"];
         $carrerataxi = CarreraTaxi::find_by_id($id);
         if($carrerataxi !=NULL){
             
             $_SESSION["carrerataxi.encontrado"] = $carrerataxi;
              header("Location: ../taxi/buscar_taxi.php?mensaje=ok,taxi encontrado");
         }
         else{
             header("Location: ../taxi/buscar_taxi.php?mensaje= taxi no existe");
         }
    }
    public static function guardar_taxi() {
        $id = $_REQUEST["id"];
        $cliente = $_REQUEST["cliente"];
        $taxi = $_REQUEST["taxi"];
        $kilometros = $_REQUEST["kilometros"];
        $barrio_inicio = $_REQUEST["barrio_inicio"];
        $barrio_llegada = $_REQUEST["barrio_llegada"];
        $cantidad_pasajeros = $_REQUEST["cantidad_pasajeros"];
        $taxista = $_REQUEST["taxista"];
         $precio = $_REQUEST["precio"];
           $duracion_minutos = $_REQUEST["duracion_minutos"];
//        echo "$cedula ,
//           $clave, $nombre, $apellido,$genero,
//                        $email";
                
                $taxi = new  Taxi(); 
                 $taxi ->id = $id;
                $taxi ->cliente = $cliente;
                $taxi ->taxi = $taxi;
             $taxi ->kilometros = $kilometros;
             $taxi ->barrio_inicio = $barrio_inicio;
             $taxi ->barrio_llegada = $barrio_llegada;
             $taxi ->cantidad_pasajeros = $cantidad_pasajeros;
             $taxi ->taxista = $taxista;
             $taxi ->barrio_llegada = $barrio_llegada;
             $taxi ->cantidad_pasajeros = $cantidad_pasajeros;
             $taxi ->taxista = $taxista;
             $taxi ->precio = $precio;
             $taxi ->duracion_minutos = $duracion_minutos;
             $res = $taxi->save(); 
             if($res==TRUE){
                 header("Location: ../taxi/agregar_taxi.php?mensaje=ok, propietario guadado");
                 
             }
             else{
                 header("Location: ../taxi/agregar_taxi.php?mensaje=Error: $taxi->errors");
                
             }
    }
}
//ControlTaxi::recuperar_accion();
$control = new ControlTaxi();
$control->recuperar_accion();
