<?php
session_start();
include_once '../../modelo/entidades/usuario.php';

$usuario = @$_SESSION["usuario"];
$usuario = @unserialize($usuario);
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>::EJEMPLO SIMPLE CON PHP Y MySQL ::</title>
</head>
<body>
<center>
    <h2>FORMULARIO PARA BUSCAR y EDITAR USUARIOS<h2>
    <hr/>
    <form action="../../controladores/Controladorusuarios.php" method="POST">
        <fieldset style="width: 20%; text-align:left">
        <legend style="color:blue">Ingrese los datos de acceso: </legend>
        <table border="0">
            
            
        <tr>  
            <th>CEDULA:</th>
            <td>
                <input name="cedula" type="number"  value="<?=@$usuario->cedula?>"<?=(isset($usuario)==true)?"readonly":"required"?>/>
            </td>
        </tr>

        <tr>
        <th>PASSWORD:</th>
                <td>
                <input name="clave" type="password"  value="<?=@$usuario->pass?>"<?=(isset($usuario)==true)?"":"readonly"?>/>
        </td>


        </tr>
                <tr>
                <th>NOMBRE:</th>
                <td>
                <input name="nombre" type="text"  value="<?=@$usuario->nombre?>"<?=(isset($usuario)==true)?"":"readonly"?>/>
                </td>
        </tr>

        </tr>
        <tr>
                        <th>APELLIDO:</th>
                        <td>
                        <input name="apellido" type="text"  value="<?=@$usuario->apellido?>"<?=(isset($usuario)==true)?"":"readonly"?>/>
                        </td>
        </tr>


        </tr>
        <tr>
                        <th>GENERO:</th>
                        <td>
                        <input name="genero" type="text"  value="<?=@$usuario->genero?>"<?=(isset($usuario)==true)?"":"readonly"?> />
                        </td>
        </tr>



        </tr>
        <tr>
                        <th>EMAIL:</th>
                        <td>
                        <input name="email" type="text"  value="<?=@$usuario->email?>" <?=(isset($usuario)==true)?  "": "readonly"?>/>
                        </td>
        </tr>

        <tr>
                        <td colspan="2" style="text-aling:center">
                        <input name="pagina" type="hidden" value="EDITAR"/>
                        <input name="accion" type="submit" value="BUSCAR"/>&nbsp;&nbsp;&nbsp;
                        <input name="accion" type="submit" value="EDITAR"/>&nbsp;&nbsp;&nbsp;
                        <input type="reset" value="Limpiar"/>
                        </td>

        </tr>
        </table>
        </fieldset>
        </form>
    <span style="color: red"><?=@($_REQUEST["mensaje"])?$_REQUEST["mensaje"]:""?></span>

</center>
</body>
</html>
